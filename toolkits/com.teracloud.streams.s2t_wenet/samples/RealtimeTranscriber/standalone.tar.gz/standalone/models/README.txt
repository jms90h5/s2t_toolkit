This is a placeholder for the real model files
